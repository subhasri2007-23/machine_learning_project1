import streamlit as st
import pandas as pd
import google.generativeai as genai
import random

st.set_page_config(
    page_title="Holographic Placement Suite",
    page_icon="🚀",
    layout="wide"
)

# ---------- CSS ----------
st.markdown("""
<style>
.stApp {
    background: gold;
    color: red;
}

.hero {
    padding: 35px;
    border-radius: 25px;
    background: rgba(255,255,255,0.08);
    backdrop-filter: blur(18px);
    border: 1px solid rgba(255,255,255,0.2);
    box-shadow: 0 0 30px rgba(0,255,255,0.3);
    text-align: center;
    margin-bottom: 25px;
}

.card {
    background: rgb(23,23,23,0.2);
    backdrop-filter: blur(15px);
    border-radius: 20px;
    padding: 20px;
    margin-bottom: 20px;
    border: 1px solid rgba(255,255,255,0.15);
    box-shadow: 0 0 20px rgba(0,255,255,0.2);
}

.metric {
    background: linear-gradient(135deg, #06b6d4, #7c3aed);
    padding: 20px;
    border-radius: 20px;
    text-align: center;
    color: white;
    box-shadow: 0 0 25px rgba(124,58,237,0.5);
}

.chat-user {
    background: rgba(59,130,246,0.2);
    padding: 12px;
    border-radius: 12px;
    margin: 8px 0;
}

.chat-bot {
    background: purple;
    padding: 12px;
    border-radius: 12px;
    margin: 8px 0;
}
</style>
""", unsafe_allow_html=True)

# ---------- LOGIN ----------
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if not st.session_state.logged_in:

    st.markdown("""
    <div class="hero">
        <h1>🚀 Holographic Placement Portal</h1>
        <p>AI Powered Student Placement System</p>
    </div>
    """, unsafe_allow_html=True)

    col1, col2, col3 = st.columns([1,2,1])

    with col2:
        st.markdown('<div class="card">', unsafe_allow_html=True)

        st.subheader("🔐 Login")

        username = st.text_input("Username")
        password = st.text_input("Password", type="password")

        if st.button("Login"):

            if username == "admin" and password == "admin123":

                st.session_state.logged_in = True
                st.success("Login Successful")
                st.rerun()

            else:
                st.error("Invalid Credentials")

        st.markdown("</div>", unsafe_allow_html=True)

else:

    # ---------- SIDEBAR ----------
    st.sidebar.title("🚀 Navigation")

    page = st.sidebar.radio(
        "Select",
        [
            "Dashboard",
            "Student Registration",
            "Placement Analytics",
            "Companies",
            "AI Chatbot",
            "Resume Tips",
            "Logout"
        ]
    )

    # ---------- DASHBOARD ----------
    if page == "Dashboard":

        st.markdown("""
        <div class="hero">
            <h1>🎓 Student Placement Dashboard</h1>
            <p>Track placements, companies, and student performance</p>
        </div>
        """, unsafe_allow_html=True)

        c1, c2, c3 = st.columns(3)

        with c1:
            st.markdown(
                '<div class="metric"><h2>350+</h2><p>Placed Students</p></div>',
                unsafe_allow_html=True
            )

        with c2:
            st.markdown(
                '<div class="metric"><h2>80+</h2><p>Recruiters</p></div>',
                unsafe_allow_html=True
            )

        with c3:
            st.markdown(
                '<div class="metric"><h2>96%</h2><p>Placement Rate</p></div>',
                unsafe_allow_html=True
            )

        st.markdown("## 🌟 Features")

        st.markdown("""
        - AI Placement Chatbot
        - Resume Guidance
        - Placement Analytics
        - Student Registration
        - Holographic Glassmorphism UI
        """)

    # ---------- REGISTRATION ----------
    elif page == "Student Registration":

        st.title("📝 Student Registration")

        with st.form("register"):

            name = st.text_input("Student Name")

            dept = st.selectbox(
                "Department",
                ["CSE", "IT", "ECE", "EEE", "MECH"]
            )

            cgpa = st.slider("CGPA", 0.0, 10.0, 7.5)

            skills = st.text_area("Skills")

            resume = st.file_uploader("Upload Resume")

            submit = st.form_submit_button("Register")

            if submit:
                st.success(f"{name} registered successfully!")

    # ---------- ANALYTICS ----------
    elif page == "Placement Analytics":

        st.title("📊 Placement Analytics")

        df = pd.DataFrame({
            "Department": ["CSE", "IT", "ECE", "EEE", "MECH"],
            "Placed Students": [120, 90, 70, 50, 40]
        })

        st.markdown('<div class="card">', unsafe_allow_html=True)

        st.dataframe(df, use_container_width=True)

        st.markdown('</div>', unsafe_allow_html=True)

        st.bar_chart(df.set_index("Department"))

    # ---------- COMPANIES ----------
    elif page == "Companies":

        st.title("🏢 Top Recruiting Companies")

        companies = [
            "TCS",
            "Infosys",
            "Wipro",
            "Zoho",
            "Google",
            "Amazon",
            "Microsoft"
        ]

        for company in companies:

            st.markdown(f'''
            <div class="card">
                <h3>{company}</h3>
                <p>Hiring for Software Developer Roles</p>
            </div>
            ''', unsafe_allow_html=True)

    # ---------- CHATBOT ----------
    elif page == "AI Chatbot":

        st.title("🤖 AI Placement Chatbot")

        # ---------- GEMINI API ----------
        API_KEY = "AIzaSyA8aU1xbHLmv1jKw8MrWBE8r8ElwxISEVw"

        genai.configure(api_key=API_KEY)

        model = genai.GenerativeModel("gemini-flash-latest")

        # ---------- SESSION ----------
        if "messages" not in st.session_state:
            st.session_state.messages = []

        # ---------- USER INPUT ----------
        user_input = st.text_input("💬 Ask your placement question")

        if st.button("Send"):

            if user_input.strip() != "":

                try:

                    response = model.generate_content(user_input)

                    bot_reply = response.text

                except Exception as e:

                    bot_reply = f"Error: {e}"

                # Store messages
                st.session_state.messages.append(("You", user_input))
                st.session_state.messages.append(("Bot", bot_reply))

        # ---------- DISPLAY CHAT ----------
        for sender, msg in st.session_state.messages:

            if sender == "You":

                st.markdown(
                    f'''
                    <div class="chat-user">
                        <b>🧑 You:</b> {msg}
                    </div>
                    ''',
                    unsafe_allow_html=True
                )

            else:

                st.markdown(
                    f'''
                    <div class="chat-bot">
                        <b>🤖 GEM BOT:</b> {msg}
                    </div>
                    ''',
                    unsafe_allow_html=True
                )

    # ---------- RESUME TIPS ----------
    elif page == "Resume Tips":

        st.title("📄 Resume Tips")

        tips = [
            "Keep resume to one page",
            "Add internship experience",
            "Mention projects clearly",
            "Include technical skills",
            "Use clean formatting"
        ]

        for tip in tips:

            st.markdown(f'''
            <div class="card">
                ✅ {tip}
            </div>
            ''', unsafe_allow_html=True)

    # ---------- LOGOUT ----------
    elif page == "Logout":

        st.session_state.logged_in = False
        st.rerun()