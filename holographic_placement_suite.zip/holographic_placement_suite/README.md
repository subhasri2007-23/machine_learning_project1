
# 🚀 Holographic Placement Suite

A futuristic Streamlit Student Placement Portal + AI Chatbot.

## Features
- Holographic Glassmorphism UI
- Login Page
- Student Registration
- Placement Analytics
- AI Placement Chatbot
- Resume Tips
- Company Dashboard

## Login Credentials
Username: admin
Password: admin123

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```
